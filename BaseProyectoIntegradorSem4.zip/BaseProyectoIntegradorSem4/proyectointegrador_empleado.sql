CREATE DATABASE  IF NOT EXISTS `proyectointegrador` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `proyectointegrador`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: proyectointegrador
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `empleado`
--

DROP TABLE IF EXISTS `empleado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleado` (
  `idEmpleado` int NOT NULL AUTO_INCREMENT,
  `foto` blob,
  `huella` int DEFAULT NULL,
  `cedula` varchar(10) NOT NULL,
  `nombreEmpleado` varchar(50) NOT NULL,
  `fechaNacimiento` date NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `telefono` varchar(10) NOT NULL,
  `fechaContratacion` date NOT NULL,
  `idDepartamento` int NOT NULL,
  `idCargo` int NOT NULL,
  `isDeleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`idEmpleado`),
  UNIQUE KEY `cedula` (`cedula`),
  UNIQUE KEY `telefono` (`telefono`),
  KEY `idDepartamento` (`idDepartamento`),
  KEY `idCargo` (`idCargo`),
  KEY `fk_huella` (`huella`),
  CONSTRAINT `empleado_ibfk_1` FOREIGN KEY (`idDepartamento`) REFERENCES `departamento` (`idDepartamento`),
  CONSTRAINT `empleado_ibfk_2` FOREIGN KEY (`idCargo`) REFERENCES `cargo` (`idCargo`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleado`
--

LOCK TABLES `empleado` WRITE;
/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
INSERT INTO `empleado` VALUES (35,NULL,1,'1759026533','Michael Castro','2025-03-28','Direccion Michael','0980278853','2025-03-28',23,12,0),(36,NULL,2,'1759026532','Estenio Moreira','2025-03-28','Direccion Estenio Moreira','099099099','2025-03-28',19,6,0),(37,NULL,3,'1759026531','Adrian Valencia','2025-03-28','Direccion Adrian Valencia','098098098','2025-03-28',24,8,0),(38,NULL,4,'1759026530','Adriana Valencia','2025-03-28','DIreccion Adriana Valencia','0970970','2025-03-28',19,7,0),(39,NULL,7,'1759036535','Sayuri Cerna','2025-03-28','Direccion sayuri','0980277855','2025-03-28',23,12,0),(40,NULL,0,'1759026534','Wilthon Baque','2025-03-28','Direccion Wilthon','0980277854','2025-03-28',23,12,0),(41,NULL,0,'1759026529','Maryuri Pereira','2025-03-28','Direccion Maryuri Pereira','091091091','2025-03-28',25,11,0),(42,NULL,5,'1','empleado1','2025-03-28','1','1','2025-03-28',26,13,1),(43,NULL,0,'2','empleado2','2025-04-04','2','2','2025-04-04',26,13,1),(44,NULL,0,'3','empleado3','2025-04-04','3','3','2025-04-04',26,13,1),(45,NULL,0,'4','empleado4','2025-04-04','4','4','2025-04-04',26,13,1),(46,NULL,0,'5','empleado5','2025-04-04','5','5','2025-04-04',26,13,1),(47,NULL,0,'6','empleado6','2025-04-04','6','6','2025-04-04',26,13,1),(48,NULL,0,'7','empleado7','2025-04-04','7','7','2025-04-04',26,13,1),(49,NULL,0,'8','empleado8','2025-04-04','8','8','2025-04-04',26,13,1),(50,NULL,0,'9','empleado9','2025-04-04','9','9','2025-04-04',26,13,1),(51,NULL,0,'10','empleado10','2025-04-04','10','10','2025-04-04',26,13,1),(52,NULL,0,'77288373','nombreapellido','2024-11-12','direccion','','2025-04-09',19,6,1),(54,NULL,6,'8887887887','nombreehsssssssssssss','2025-04-09','direcccccccccc','9999999999','2025-04-09',24,8,1),(55,NULL,0,'666','seis','2025-04-11','seis','6677','2025-04-11',19,7,1),(56,NULL,0,'0000000001','servitec','2001-01-01','Av. Quito y Av. Lorena','0980634737','2025-04-12',19,6,0),(58,NULL,0,'9999999999','apeliido','2025-04-12','shcdef','3e4','2025-04-12',19,22,1),(59,NULL,0,'111133','nuevonuveo','2025-04-12','nuevonuvek','9876456789','2025-04-12',24,10,1),(60,NULL,0,'1111111111','EmpPrueba1','2000-02-01','Dirección de EmpPrueba1','1111111111','2025-04-15',24,8,0),(61,NULL,0,'2222222222','EmpPrueba2','2000-02-20','Direccion EmpPrueba2','2222222222','2025-04-15',24,8,0),(62,NULL,0,'3333333333','EmpPrueba3','2000-02-06','Direccion EmpPrueba3','3333333333','2025-04-15',24,8,0),(63,NULL,0,'4444444444','EmpPrueba4','2003-06-09','Direccion EmpPrueba4','4444444444','2025-04-15',24,8,0),(64,NULL,0,'5555555555','EmpPrueba5','2001-01-21','Direccion EmpPrueba5','5555555555','2025-04-15',24,8,0),(65,NULL,0,'6666666666','EmpPrueba6','2025-04-15','Direccion EmpPrueba6','6666666666','2025-04-15',24,8,0),(66,NULL,0,'7777777777','EmpPrueba7','2025-04-15','direccion EmpPrueba7','7777777777','2025-04-15',24,8,0),(67,NULL,0,'8888888888','EmpPrueba8','2003-02-10','Direccion EmpPrueba8','8888888888','2025-04-15',24,8,0),(68,NULL,8,'1891819177','valentina cerna','2000-01-24','Direccion 1891819177','1891819177','2025-04-15',23,12,0),(69,NULL,9,'1738428836','Javier Cerna','2004-06-15','Direccion 1738428836','1738428836','2025-04-15',23,12,0);
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-03 22:11:02
