CREATE DATABASE  IF NOT EXISTS `proyectointegrador` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `proyectointegrador`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: proyectointegrador
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `vista_asistencia_diaria`
--

DROP TABLE IF EXISTS `vista_asistencia_diaria`;
/*!50001 DROP VIEW IF EXISTS `vista_asistencia_diaria`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_asistencia_diaria` AS SELECT 
 1 AS `idEmpleado`,
 1 AS `nombreEmpleado`,
 1 AS `nombreDepartamento`,
 1 AS `fecha`,
 1 AS `horaEntrada`,
 1 AS `horaSalida`,
 1 AS `horasTrabajadas`,
 1 AS `horasExtras`,
 1 AS `horasSuplementarias`,
 1 AS `horasNOTrabajadas`,
 1 AS `justificado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_sueldos_pagados_mensual`
--

DROP TABLE IF EXISTS `vw_sueldos_pagados_mensual`;
/*!50001 DROP VIEW IF EXISTS `vw_sueldos_pagados_mensual`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_sueldos_pagados_mensual` AS SELECT 
 1 AS `anio`,
 1 AS `mes`,
 1 AS `totalSueldosPagados`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_anticipos`
--

DROP TABLE IF EXISTS `vista_anticipos`;
/*!50001 DROP VIEW IF EXISTS `vista_anticipos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_anticipos` AS SELECT 
 1 AS `idAnticipo`,
 1 AS `idEmpleado`,
 1 AS `nombreEmpleado`,
 1 AS `fecha`,
 1 AS `monto`,
 1 AS `motivo`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_ingresos_egresos_mensual`
--

DROP TABLE IF EXISTS `vw_ingresos_egresos_mensual`;
/*!50001 DROP VIEW IF EXISTS `vw_ingresos_egresos_mensual`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_ingresos_egresos_mensual` AS SELECT 
 1 AS `anio`,
 1 AS `mes`,
 1 AS `totalIngresos`,
 1 AS `totalEgresos`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_departamento_cargos`
--

DROP TABLE IF EXISTS `vista_departamento_cargos`;
/*!50001 DROP VIEW IF EXISTS `vista_departamento_cargos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_departamento_cargos` AS SELECT 
 1 AS `idDepartamento`,
 1 AS `nombreDepartamento`,
 1 AS `numeroCargos`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_empleados_completa`
--

DROP TABLE IF EXISTS `vista_empleados_completa`;
/*!50001 DROP VIEW IF EXISTS `vista_empleados_completa`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_empleados_completa` AS SELECT 
 1 AS `idEmpleado`,
 1 AS `huella`,
 1 AS `cedula`,
 1 AS `nombreEmpleado`,
 1 AS `fechaNacimiento`,
 1 AS `direccion`,
 1 AS `telefono`,
 1 AS `fechaContratacion`,
 1 AS `nombreDepartamento`,
 1 AS `nombreCargo`,
 1 AS `huellaRegistrada`,
 1 AS `estado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_asistencias`
--

DROP TABLE IF EXISTS `vista_asistencias`;
/*!50001 DROP VIEW IF EXISTS `vista_asistencias`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_asistencias` AS SELECT 
 1 AS `idAsistencia`,
 1 AS `idEmpleado`,
 1 AS `nombreEmpleado`,
 1 AS `fecha`,
 1 AS `horaEntrada`,
 1 AS `horaSalida`,
 1 AS `horasTrabajadasTiempo`,
 1 AS `horasSuplementariasTiempo`,
 1 AS `horasExtrasTiempo`,
 1 AS `horasNOTrabajadasTiempo`,
 1 AS `Justificado`,
 1 AS `MotivoJustificacion`,
 1 AS `DetalleJustificacion`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwatt`
--

DROP TABLE IF EXISTS `vwatt`;
/*!50001 DROP VIEW IF EXISTS `vwatt`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwatt` AS SELECT 
 1 AS `ID`,
 1 AS `Empleado`,
 1 AS `Fecha`,
 1 AS `Entrada`,
 1 AS `Salida`,
 1 AS `Justificación`,
 1 AS `Motivo`,
 1 AS `Detalle`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_rol_pago_detallada`
--

DROP TABLE IF EXISTS `vista_rol_pago_detallada`;
/*!50001 DROP VIEW IF EXISTS `vista_rol_pago_detallada`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_rol_pago_detallada` AS SELECT 
 1 AS `idRol`,
 1 AS `numRol`,
 1 AS `mes`,
 1 AS `anio`,
 1 AS `fechaEmision`,
 1 AS `idEmpleado`,
 1 AS `nombreEmpleado`,
 1 AS `cedula`,
 1 AS `nombreCargo`,
 1 AS `nombreDepartamento`,
 1 AS `sueldo`,
 1 AS `horasSuplementarias`,
 1 AS `horasExtras`,
 1 AS `decimotercerSueldo`,
 1 AS `decimocuartoSueldo`,
 1 AS `fondoReserva`,
 1 AS `aporteIess`,
 1 AS `anticipos`,
 1 AS `otrosDescuentos`,
 1 AS `descuentoTardanzas`,
 1 AS `totalEgresos`,
 1 AS `totalIngresos`,
 1 AS `netoPagar`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwusers`
--

DROP TABLE IF EXISTS `vwusers`;
/*!50001 DROP VIEW IF EXISTS `vwusers`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwusers` AS SELECT 
 1 AS `Nombre de Usuario`,
 1 AS `Contraseña`,
 1 AS `Rol`,
 1 AS `Estado`,
 1 AS `Empleado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_rol_pago_completo`
--

DROP TABLE IF EXISTS `vw_rol_pago_completo`;
/*!50001 DROP VIEW IF EXISTS `vw_rol_pago_completo`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_rol_pago_completo` AS SELECT 
 1 AS `idRol`,
 1 AS `numRol`,
 1 AS `mes`,
 1 AS `anio`,
 1 AS `empleado`,
 1 AS `departamento`,
 1 AS `cargo`,
 1 AS `sueldo`,
 1 AS `horasSuplementarias`,
 1 AS `horasExtras`,
 1 AS `decimotercerSueldo`,
 1 AS `decimocuartoSueldo`,
 1 AS `fondoReserva`,
 1 AS `totalIngresos`,
 1 AS `aporteIess`,
 1 AS `anticipos`,
 1 AS `otrosDescuentos`,
 1 AS `totalEgresos`,
 1 AS `netoPagar`,
 1 AS `fechaEmision`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_auditorias`
--

DROP TABLE IF EXISTS `vista_auditorias`;
/*!50001 DROP VIEW IF EXISTS `vista_auditorias`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_auditorias` AS SELECT 
 1 AS `idAuditoria`,
 1 AS `tablaAfectada`,
 1 AS `tipoAccion`,
 1 AS `descripcion`,
 1 AS `fechaHora`,
 1 AS `usuarioResponsable`,
 1 AS `rolUsuario`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_empleados_gestion`
--

DROP TABLE IF EXISTS `vista_empleados_gestion`;
/*!50001 DROP VIEW IF EXISTS `vista_empleados_gestion`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_empleados_gestion` AS SELECT 
 1 AS `idEmpleado`,
 1 AS `huella`,
 1 AS `cedula`,
 1 AS `nombreEmpleado`,
 1 AS `fechaNacimiento`,
 1 AS `direccion`,
 1 AS `telefono`,
 1 AS `fechaContratacion`,
 1 AS `idDepartamento`,
 1 AS `idCargo`,
 1 AS `nombreDepartamento`,
 1 AS `nombreCargo`,
 1 AS `huellaRegistrada`,
 1 AS `estado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_usuarios_empleados`
--

DROP TABLE IF EXISTS `vista_usuarios_empleados`;
/*!50001 DROP VIEW IF EXISTS `vista_usuarios_empleados`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_usuarios_empleados` AS SELECT 
 1 AS `idUsuario`,
 1 AS `nombreUsuario`,
 1 AS `contrasenia`,
 1 AS `rolUsuario`,
 1 AS `estado`,
 1 AS `isDeleted`,
 1 AS `idEmpleado`,
 1 AS `nombreEmpleado`,
 1 AS `empleadoIsDeleted`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_cargos`
--

DROP TABLE IF EXISTS `vista_cargos`;
/*!50001 DROP VIEW IF EXISTS `vista_cargos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_cargos` AS SELECT 
 1 AS `idCargo`,
 1 AS `nombreCargo`,
 1 AS `salario`,
 1 AS `nombreDepartamento`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vista_empleados_activos`
--

DROP TABLE IF EXISTS `vista_empleados_activos`;
/*!50001 DROP VIEW IF EXISTS `vista_empleados_activos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_empleados_activos` AS SELECT 
 1 AS `idEmpleado`,
 1 AS `cedula`,
 1 AS `nombreEmpleado`,
 1 AS `fechaNacimiento`,
 1 AS `direccion`,
 1 AS `telefono`,
 1 AS `fechaContratacion`,
 1 AS `nombreDepartamento`,
 1 AS `nombreCargo`,
 1 AS `salario`,
 1 AS `tieneUsuario`,
 1 AS `nombreUsuario`,
 1 AS `rolUsuario`,
 1 AS `estadoUsuario`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwposdpt`
--

DROP TABLE IF EXISTS `vwposdpt`;
/*!50001 DROP VIEW IF EXISTS `vwposdpt`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwposdpt` AS SELECT 
 1 AS `Cargo`,
 1 AS `Salario`,
 1 AS `Departamento`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vwemp`
--

DROP TABLE IF EXISTS `vwemp`;
/*!50001 DROP VIEW IF EXISTS `vwemp`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vwemp` AS SELECT 
 1 AS `idEmpleado`,
 1 AS `foto`,
 1 AS `huella`,
 1 AS `cedula`,
 1 AS `nombreEmpleado`,
 1 AS `fechaNacimiento`,
 1 AS `direccion`,
 1 AS `telefono`,
 1 AS `fechaContratacion`,
 1 AS `idDepartamento`,
 1 AS `nombreDepartamento`,
 1 AS `idCargo`,
 1 AS `nombreCargo`,
 1 AS `salario`,
 1 AS `isDeleted`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vista_asistencia_diaria`
--

/*!50001 DROP VIEW IF EXISTS `vista_asistencia_diaria`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_asistencia_diaria` AS select `e`.`idEmpleado` AS `idEmpleado`,`e`.`nombreEmpleado` AS `nombreEmpleado`,`d`.`nombreDepartamento` AS `nombreDepartamento`,`a`.`fecha` AS `fecha`,`a`.`horaEntrada` AS `horaEntrada`,`a`.`horaSalida` AS `horaSalida`,`a`.`horasTrabajadas` AS `horasTrabajadas`,`a`.`horasExtras` AS `horasExtras`,`a`.`horasSuplementarias` AS `horasSuplementarias`,`a`.`horasNOTrabajadas` AS `horasNOTrabajadas`,(case when (`a`.`justificado` = true) then 'Sí' else 'No' end) AS `justificado` from ((`asistencia` `a` join `empleado` `e` on((`a`.`idEmpleado` = `e`.`idEmpleado`))) join `departamento` `d` on((`e`.`idDepartamento` = `d`.`idDepartamento`))) where ((`a`.`fecha` = curdate()) and (`a`.`isDeleted` = false)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_sueldos_pagados_mensual`
--

/*!50001 DROP VIEW IF EXISTS `vw_sueldos_pagados_mensual`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_sueldos_pagados_mensual` AS select `rp`.`anio` AS `anio`,`rp`.`mes` AS `mes`,sum(`rp`.`netoPagar`) AS `totalSueldosPagados` from `rolpago` `rp` where (`rp`.`isDeleted` = false) group by `rp`.`anio`,`rp`.`mes` order by `rp`.`anio`,`rp`.`mes` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_anticipos`
--

/*!50001 DROP VIEW IF EXISTS `vista_anticipos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_anticipos` AS select `a`.`idAnticipo` AS `idAnticipo`,`a`.`idEmpleado` AS `idEmpleado`,`e`.`nombreEmpleado` AS `nombreEmpleado`,`a`.`fecha` AS `fecha`,`a`.`monto` AS `monto`,`a`.`motivo` AS `motivo` from (`anticipo` `a` join `empleado` `e` on((`a`.`idEmpleado` = `e`.`idEmpleado`))) where (`a`.`isDeleted` = false) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_ingresos_egresos_mensual`
--

/*!50001 DROP VIEW IF EXISTS `vw_ingresos_egresos_mensual`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_ingresos_egresos_mensual` AS select `rp`.`anio` AS `anio`,`rp`.`mes` AS `mes`,sum(`rp`.`totalIngresos`) AS `totalIngresos`,sum(`rp`.`totalEgresos`) AS `totalEgresos` from `rolpago` `rp` where (`rp`.`isDeleted` = false) group by `rp`.`anio`,`rp`.`mes` order by `rp`.`anio`,`rp`.`mes` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_departamento_cargos`
--

/*!50001 DROP VIEW IF EXISTS `vista_departamento_cargos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_departamento_cargos` AS select `d`.`idDepartamento` AS `idDepartamento`,`d`.`nombreDepartamento` AS `nombreDepartamento`,count(`c`.`idCargo`) AS `numeroCargos` from (`departamento` `d` left join `cargo` `c` on(((`d`.`idDepartamento` = `c`.`idDepartamento`) and (`c`.`isDeleted` = false)))) where (`d`.`isDeleted` = false) group by `d`.`idDepartamento`,`d`.`nombreDepartamento` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_empleados_completa`
--

/*!50001 DROP VIEW IF EXISTS `vista_empleados_completa`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_empleados_completa` AS select `e`.`idEmpleado` AS `idEmpleado`,`e`.`huella` AS `huella`,`e`.`cedula` AS `cedula`,`e`.`nombreEmpleado` AS `nombreEmpleado`,`e`.`fechaNacimiento` AS `fechaNacimiento`,`e`.`direccion` AS `direccion`,`e`.`telefono` AS `telefono`,`e`.`fechaContratacion` AS `fechaContratacion`,`d`.`nombreDepartamento` AS `nombreDepartamento`,`c`.`nombreCargo` AS `nombreCargo`,(case when ((`e`.`huella` is not null) and (`e`.`huella` <> 0)) then 'Sí' else 'No' end) AS `huellaRegistrada`,(case when (`e`.`isDeleted` = false) then 'Activo' else 'Inactivo' end) AS `estado` from ((`empleado` `e` join `departamento` `d` on((`e`.`idDepartamento` = `d`.`idDepartamento`))) join `cargo` `c` on((`e`.`idCargo` = `c`.`idCargo`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_asistencias`
--

/*!50001 DROP VIEW IF EXISTS `vista_asistencias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_asistencias` AS select `a`.`idAsistencia` AS `idAsistencia`,`a`.`idEmpleado` AS `idEmpleado`,`e`.`nombreEmpleado` AS `nombreEmpleado`,`a`.`fecha` AS `fecha`,`a`.`horaEntrada` AS `horaEntrada`,`a`.`horaSalida` AS `horaSalida`,`a`.`horasTrabajadasTiempo` AS `horasTrabajadasTiempo`,`a`.`horasSuplementariasTiempo` AS `horasSuplementariasTiempo`,`a`.`horasExtrasTiempo` AS `horasExtrasTiempo`,`a`.`horasNOTrabajadasTiempo` AS `horasNOTrabajadasTiempo`,(case when `a`.`justificado` then 'Sí' else 'No' end) AS `Justificado`,`j`.`motivo` AS `MotivoJustificacion`,`j`.`detalle` AS `DetalleJustificacion` from ((`asistencia` `a` join `empleado` `e` on((`a`.`idEmpleado` = `e`.`idEmpleado`))) left join `justificacion` `j` on((`a`.`idJustificacion` = `j`.`idJustificacion`))) where (`a`.`isDeleted` = false) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwatt`
--

/*!50001 DROP VIEW IF EXISTS `vwatt`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwatt` AS select `a`.`idAsistencia` AS `ID`,`e`.`nombreEmpleado` AS `Empleado`,`a`.`fecha` AS `Fecha`,`a`.`horaEntrada` AS `Entrada`,`a`.`horaSalida` AS `Salida`,`a`.`justificado` AS `Justificación`,`j`.`motivo` AS `Motivo`,`j`.`detalle` AS `Detalle` from ((`asistencia` `a` join `empleado` `e` on((`a`.`idEmpleado` = `e`.`idEmpleado`))) left join `justificacion` `j` on((`a`.`idJustificacion` = `j`.`idJustificacion`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_rol_pago_detallada`
--

/*!50001 DROP VIEW IF EXISTS `vista_rol_pago_detallada`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_rol_pago_detallada` AS select `rp`.`idRol` AS `idRol`,`rp`.`numRol` AS `numRol`,`rp`.`mes` AS `mes`,`rp`.`anio` AS `anio`,`rp`.`fechaEmision` AS `fechaEmision`,`e`.`idEmpleado` AS `idEmpleado`,`e`.`nombreEmpleado` AS `nombreEmpleado`,`e`.`cedula` AS `cedula`,`c`.`nombreCargo` AS `nombreCargo`,`d`.`nombreDepartamento` AS `nombreDepartamento`,`rp`.`sueldo` AS `sueldo`,`rp`.`horasSuplementarias` AS `horasSuplementarias`,`rp`.`horasExtras` AS `horasExtras`,`rp`.`decimotercerSueldo` AS `decimotercerSueldo`,`rp`.`decimocuartoSueldo` AS `decimocuartoSueldo`,`rp`.`fondoReserva` AS `fondoReserva`,`rp`.`aporteIess` AS `aporteIess`,`rp`.`anticipos` AS `anticipos`,`rp`.`otrosDescuentos` AS `otrosDescuentos`,`rp`.`descuentoTardanzas` AS `descuentoTardanzas`,`rp`.`totalEgresos` AS `totalEgresos`,`rp`.`totalIngresos` AS `totalIngresos`,`rp`.`netoPagar` AS `netoPagar` from (((`rolpago` `rp` join `empleado` `e` on((`rp`.`idEmpleado` = `e`.`idEmpleado`))) join `cargo` `c` on((`e`.`idCargo` = `c`.`idCargo`))) join `departamento` `d` on((`e`.`idDepartamento` = `d`.`idDepartamento`))) where (`rp`.`isDeleted` = false) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwusers`
--

/*!50001 DROP VIEW IF EXISTS `vwusers`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwusers` AS select `u`.`nombreUsuario` AS `Nombre de Usuario`,`u`.`contrasenia` AS `Contraseña`,`u`.`rolUsuario` AS `Rol`,`u`.`estado` AS `Estado`,`e`.`nombreEmpleado` AS `Empleado` from (`usuario` `u` join `empleado` `e` on((`u`.`idEmpleado` = `e`.`idEmpleado`))) where (`u`.`isDeleted` = false) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_rol_pago_completo`
--

/*!50001 DROP VIEW IF EXISTS `vw_rol_pago_completo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_rol_pago_completo` AS select `r`.`idRol` AS `idRol`,`r`.`numRol` AS `numRol`,`r`.`mes` AS `mes`,`r`.`anio` AS `anio`,`e`.`nombreEmpleado` AS `empleado`,`d`.`nombreDepartamento` AS `departamento`,`c`.`nombreCargo` AS `cargo`,`r`.`sueldo` AS `sueldo`,`r`.`horasSuplementarias` AS `horasSuplementarias`,`r`.`horasExtras` AS `horasExtras`,`r`.`decimotercerSueldo` AS `decimotercerSueldo`,`r`.`decimocuartoSueldo` AS `decimocuartoSueldo`,`r`.`fondoReserva` AS `fondoReserva`,`r`.`totalIngresos` AS `totalIngresos`,`r`.`aporteIess` AS `aporteIess`,`r`.`anticipos` AS `anticipos`,`r`.`otrosDescuentos` AS `otrosDescuentos`,`r`.`totalEgresos` AS `totalEgresos`,`r`.`netoPagar` AS `netoPagar`,`r`.`fechaEmision` AS `fechaEmision` from (((`rolpago` `r` join `empleado` `e` on((`r`.`idEmpleado` = `e`.`idEmpleado`))) join `cargo` `c` on((`e`.`idCargo` = `c`.`idCargo`))) join `departamento` `d` on((`e`.`idDepartamento` = `d`.`idDepartamento`))) where (`r`.`isDeleted` = false) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_auditorias`
--

/*!50001 DROP VIEW IF EXISTS `vista_auditorias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_auditorias` AS select `a`.`idAuditoria` AS `idAuditoria`,`a`.`tablaAfectada` AS `tablaAfectada`,`a`.`tipoAccion` AS `tipoAccion`,`a`.`descripcion` AS `descripcion`,`a`.`fechaHora` AS `fechaHora`,`u`.`nombreUsuario` AS `usuarioResponsable`,`u`.`rolUsuario` AS `rolUsuario` from (`auditoria` `a` join `usuario` `u` on((`a`.`idUsuario` = `u`.`idUsuario`))) where (`a`.`idUsuario` is not null) order by `a`.`fechaHora` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_empleados_gestion`
--

/*!50001 DROP VIEW IF EXISTS `vista_empleados_gestion`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_empleados_gestion` AS select `e`.`idEmpleado` AS `idEmpleado`,`e`.`huella` AS `huella`,`e`.`cedula` AS `cedula`,`e`.`nombreEmpleado` AS `nombreEmpleado`,`e`.`fechaNacimiento` AS `fechaNacimiento`,`e`.`direccion` AS `direccion`,`e`.`telefono` AS `telefono`,`e`.`fechaContratacion` AS `fechaContratacion`,`e`.`idDepartamento` AS `idDepartamento`,`e`.`idCargo` AS `idCargo`,`d`.`nombreDepartamento` AS `nombreDepartamento`,`c`.`nombreCargo` AS `nombreCargo`,(case when ((`e`.`huella` is not null) and (`e`.`huella` <> 0)) then 'Sí' else 'No' end) AS `huellaRegistrada`,(case when (`e`.`isDeleted` = false) then 'Activo' else 'Inactivo' end) AS `estado` from ((`empleado` `e` join `departamento` `d` on((`e`.`idDepartamento` = `d`.`idDepartamento`))) join `cargo` `c` on((`e`.`idCargo` = `c`.`idCargo`))) where (`e`.`isDeleted` = false) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_usuarios_empleados`
--

/*!50001 DROP VIEW IF EXISTS `vista_usuarios_empleados`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_usuarios_empleados` AS select `u`.`idUsuario` AS `idUsuario`,`u`.`nombreUsuario` AS `nombreUsuario`,`u`.`contrasenia` AS `contrasenia`,`u`.`rolUsuario` AS `rolUsuario`,`u`.`estado` AS `estado`,`u`.`isDeleted` AS `isDeleted`,`e`.`idEmpleado` AS `idEmpleado`,`e`.`nombreEmpleado` AS `nombreEmpleado`,`e`.`isDeleted` AS `empleadoIsDeleted` from (`usuario` `u` join `empleado` `e` on((`u`.`idEmpleado` = `e`.`idEmpleado`))) where (`u`.`isDeleted` = 0) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_cargos`
--

/*!50001 DROP VIEW IF EXISTS `vista_cargos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_cargos` AS select `c`.`idCargo` AS `idCargo`,`c`.`nombreCargo` AS `nombreCargo`,`c`.`salario` AS `salario`,`d`.`nombreDepartamento` AS `nombreDepartamento` from (`cargo` `c` join `departamento` `d` on((`c`.`idDepartamento` = `d`.`idDepartamento`))) where ((`c`.`isDeleted` = false) and (`d`.`isDeleted` = false)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vista_empleados_activos`
--

/*!50001 DROP VIEW IF EXISTS `vista_empleados_activos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_empleados_activos` AS select `e`.`idEmpleado` AS `idEmpleado`,`e`.`cedula` AS `cedula`,`e`.`nombreEmpleado` AS `nombreEmpleado`,`e`.`fechaNacimiento` AS `fechaNacimiento`,`e`.`direccion` AS `direccion`,`e`.`telefono` AS `telefono`,cast(`e`.`fechaContratacion` as date) AS `fechaContratacion`,`d`.`nombreDepartamento` AS `nombreDepartamento`,`c`.`nombreCargo` AS `nombreCargo`,`c`.`salario` AS `salario`,(case when (`u`.`idUsuario` is not null) then 'Sí' else 'No' end) AS `tieneUsuario`,`u`.`nombreUsuario` AS `nombreUsuario`,`u`.`rolUsuario` AS `rolUsuario`,(case when (`u`.`estado` = true) then 'Activo' when (`u`.`estado` = false) then 'Inactivo' else NULL end) AS `estadoUsuario` from (((`empleado` `e` join `departamento` `d` on((`e`.`idDepartamento` = `d`.`idDepartamento`))) join `cargo` `c` on((`e`.`idCargo` = `c`.`idCargo`))) left join `usuario` `u` on(((`e`.`idEmpleado` = `u`.`idEmpleado`) and (`u`.`isDeleted` = false)))) where (`e`.`isDeleted` = false) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwposdpt`
--

/*!50001 DROP VIEW IF EXISTS `vwposdpt`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwposdpt` AS select `c`.`nombreCargo` AS `Cargo`,`c`.`salario` AS `Salario`,`d`.`nombreDepartamento` AS `Departamento` from (`cargo` `c` join `departamento` `d` on((`c`.`idDepartamento` = `d`.`idDepartamento`))) where (`c`.`isDeleted` = false) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwemp`
--

/*!50001 DROP VIEW IF EXISTS `vwemp`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vwemp` AS select `e`.`idEmpleado` AS `idEmpleado`,`e`.`foto` AS `foto`,`e`.`huella` AS `huella`,`e`.`cedula` AS `cedula`,`e`.`nombreEmpleado` AS `nombreEmpleado`,`e`.`fechaNacimiento` AS `fechaNacimiento`,`e`.`direccion` AS `direccion`,`e`.`telefono` AS `telefono`,`e`.`fechaContratacion` AS `fechaContratacion`,`e`.`idDepartamento` AS `idDepartamento`,`d`.`nombreDepartamento` AS `nombreDepartamento`,`e`.`idCargo` AS `idCargo`,`c`.`nombreCargo` AS `nombreCargo`,`c`.`salario` AS `salario`,`e`.`isDeleted` AS `isDeleted` from ((`empleado` `e` join `departamento` `d` on((`e`.`idDepartamento` = `d`.`idDepartamento`))) join `cargo` `c` on((`e`.`idCargo` = `c`.`idCargo`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 'proyectointegrador'
--

--
-- Dumping routines for database 'proyectointegrador'
--
/*!50003 DROP FUNCTION IF EXISTS `calcular_aporte_iess` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `calcular_aporte_iess`(sueldo DECIMAL(10,2), horas_suplementarias DECIMAL(10,2), horas_extras DECIMAL(10,2)) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN  
    DECLARE total_ingresos DECIMAL(10,2);  
    SET total_ingresos = (sueldo + horas_suplementarias + horas_extras)*0.0945;  
    RETURN total_ingresos;   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `calcular_decimo_cuarto` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `calcular_decimo_cuarto`() RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN  
    RETURN 470 / 12;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `calcular_decimo_tercero` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `calcular_decimo_tercero`(
    sueldo DECIMAL(10,2),
    horasSuplementarias DECIMAL(10,2),
    horasExtras DECIMAL(10,2) 
) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN
    RETURN (sueldo + horasSuplementarias + horasExtras) / 12;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `calcular_fondo_reserva` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `calcular_fondo_reserva`(sueldo DECIMAL(10,2), horas_suplementarias DECIMAL(10,2), horas_extras DECIMAL(10,2)) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN  
    DECLARE total_ingresos DECIMAL(10,2);  
    SET total_ingresos = (sueldo + horas_suplementarias + horas_extras)*0.0833;  
    RETURN total_ingresos;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `calcular_pago_horas_extras` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `calcular_pago_horas_extras`(sueldo_mensual DECIMAL(10,2), horas_extras INT) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN
    DECLARE sueldo_hora DECIMAL(10,2);
    SET sueldo_hora = calcular_sueldo_hora(sueldo_mensual);
    RETURN sueldo_hora * 2 * horas_extras;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `calcular_pago_horas_suplementarias` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `calcular_pago_horas_suplementarias`(sueldo_mensual DECIMAL(10,2), horas_suplementarias INT) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN
    DECLARE sueldo_hora DECIMAL(10,2);
    SET sueldo_hora = calcular_sueldo_hora(sueldo_mensual);
    RETURN sueldo_hora * 1.5 * horas_suplementarias;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `calcular_sueldo_diario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `calcular_sueldo_diario`(sueldo_mensual DECIMAL(10,2)) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN
    RETURN sueldo_mensual / 30;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `calcular_sueldo_hora` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `calcular_sueldo_hora`(sueldo_mensual DECIMAL(10,2)) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN
    RETURN sueldo_mensual / 30 / 8;  
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `obtenerHorasExtras` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `obtenerHorasExtras`(
    p_idEmpleado INT, 
    p_mes CHAR(2), 
    p_anio YEAR
) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN
    DECLARE totalExtras DECIMAL(10,2);

    -- Suma todas las horas extras trabajadas en el mes
    SELECT IFNULL(SUM(
        GREATEST(TIME_TO_SEC(TIMEDIFF(horaSalida, '17:00:00')) / 3600, 0)
    ), 0) 
    INTO totalExtras
    FROM asistencia 
    WHERE idEmpleado = p_idEmpleado 
    AND MONTH(fecha) = p_mes
    AND YEAR(fecha) = p_anio
    AND horaSalida > '17:00:00';  -- Solo contar si salió después de las 5pm

    RETURN totalExtras;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `obtenerHorasTrabajadas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `obtenerHorasTrabajadas`(
    p_idEmpleado INT, 
    p_mes CHAR(2), 
    p_anio YEAR
) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN
    DECLARE totalHoras DECIMAL(10,2);

    -- Suma todas las horas trabajadas en el mes
    SELECT IFNULL(SUM(horasTrabajadas), 0) 
    INTO totalHoras
    FROM asistencia 
    WHERE idEmpleado = p_idEmpleado 
    AND MONTH(fecha) = p_mes
    AND YEAR(fecha) = p_anio;

    RETURN totalHoras;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `obtener_dias_faltados` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `obtener_dias_faltados`(
    p_idEmpleado INT, 
    p_mes CHAR(2), 
    p_anio YEAR
) RETURNS int
    DETERMINISTIC
BEGIN
    DECLARE v_dias_faltados INT DEFAULT 0;
    DECLARE v_dia DATE;
    DECLARE v_last_day DATE;

    -- Construir la fecha inicial y último día del mes correctamente
    SET v_dia = CONCAT(p_anio, '-', LPAD(p_mes, 2, '0'), '-01');
    SET v_last_day = LAST_DAY(v_dia);

    WHILE v_dia <= v_last_day DO
        -- Verificar si es día laborable (Lunes a Viernes)
        IF DAYOFWEEK(v_dia) BETWEEN 2 AND 6 THEN
            -- Verificar que NO sea feriado
            IF NOT EXISTS (
                SELECT 1 
                FROM feriados 
                WHERE fechaFeriado = v_dia
            ) THEN
                -- Comprobar ausencia de registro de asistencia
                IF NOT EXISTS (
                    SELECT 1 
                    FROM asistencia 
                    WHERE idEmpleado = p_idEmpleado 
                    AND fecha = v_dia
                ) THEN
                    SET v_dias_faltados = v_dias_faltados + 1;
                END IF;
            END IF;
        END IF;
        SET v_dia = DATE_ADD(v_dia, INTERVAL 1 DAY);
    END WHILE;

    RETURN v_dias_faltados;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `actualizarHoraSalida` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `actualizarHoraSalida`(
    IN p_idEmpleado INT, 
    IN p_mes CHAR(2), 
    IN p_anio YEAR, 
    IN p_horaSalida TIME
)
BEGIN
    -- Actualiza la hora de salida en todas las asistencias del mes
    UPDATE asistencia 
    SET horaSalida = p_horaSalida
    WHERE idEmpleado = p_idEmpleado
    AND MONTH(fecha) = p_mes
    AND YEAR(fecha) = p_anio;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addDpt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `addDpt`(IN nombre VARCHAR(50))
BEGIN
    INSERT INTO departamento (nombreDepartamento) VALUES (nombre);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `CrearAnticipo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `CrearAnticipo`(
    IN p_idEmpleado INT,
    IN p_monto DECIMAL(10,2),
    IN p_motivo TEXT
)
BEGIN
    DECLARE v_salario DECIMAL(10,2);
    DECLARE v_total_anticipos_mes DECIMAL(10,2);
    DECLARE v_max_anticipo DECIMAL(10,2);
    
    -- Verificar si el empleado está activo
    IF (SELECT isDeleted FROM empleado WHERE idEmpleado = p_idEmpleado) = TRUE THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Empleado inactivo o eliminado';
    END IF;

    -- Obtener salario base del empleado
    SELECT c.salario INTO v_salario
    FROM empleado e
    JOIN cargo c ON e.idCargo = c.idCargo
    WHERE e.idEmpleado = p_idEmpleado;

    -- Calcular 50% del salario
    SET v_max_anticipo = v_salario * 0.25;

    -- Sumar anticipos del mes actual
    SELECT COALESCE(SUM(monto), 0) INTO v_total_anticipos_mes
    FROM anticipo 
    WHERE idEmpleado = p_idEmpleado
        AND MONTH(fecha) = MONTH(CURDATE())
        AND YEAR(fecha) = YEAR(CURDATE())
        AND isDeleted = FALSE;

    -- Validar límite
    IF (v_total_anticipos_mes + p_monto) > v_max_anticipo THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Límite de anticipos superado (25% del salario)';
    ELSE
        INSERT INTO anticipo (idEmpleado, fecha, monto, motivo)
        VALUES (p_idEmpleado, CURDATE(), p_monto, p_motivo);
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `deleteDpt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `deleteDpt`(IN id INT)
BEGIN
    UPDATE departamento SET isDeleted = TRUE WHERE idDepartamento = id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `EliminarAnticipo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarAnticipo`(
    IN p_idAnticipo INT
)
BEGIN
    DECLARE v_idEmpleado INT;

    -- Verificar si el anticipo existe y no está marcado como eliminado
    SELECT idEmpleado INTO v_idEmpleado
    FROM anticipo
    WHERE idAnticipo = p_idAnticipo AND isDeleted = FALSE;

    -- Si el anticipo no existe o ya está eliminado, lanzar error
    IF v_idEmpleado IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Anticipo no encontrado o ya ha sido eliminado';
    ELSE
        -- Marcar como eliminado
        UPDATE anticipo
        SET isDeleted = TRUE
        WHERE idAnticipo = p_idAnticipo;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `eliminarAsistenciasMes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `eliminarAsistenciasMes`(
    IN p_idEmpleado INT, 
    IN p_mes CHAR(2), 
    IN p_anio YEAR
)
BEGIN
    -- Elimina todas las asistencias del empleado en el mes y año indicados
    DELETE FROM asistencia 
    WHERE idEmpleado = p_idEmpleado
    AND MONTH(fecha) = p_mes
    AND YEAR(fecha) = p_anio;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `generarRolPago` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `generarRolPago`(
    IN p_numRol INT, 
    IN p_idEmpleado INT, 
    IN p_mes CHAR(2), 
    IN p_anio YEAR
)
BEGIN
    DECLARE v_sueldo DECIMAL(10,2);
    DECLARE v_horasTrabajadas DECIMAL(10,2);
    DECLARE v_horasExtras DECIMAL(10,2);
    DECLARE v_horasSuplementarias DECIMAL(10,2);
    DECLARE v_decimotercerSueldo DECIMAL(10,2);
    DECLARE v_decimocuartoSueldo DECIMAL(10,2);
    DECLARE v_fondoReserva DECIMAL(10,2);
    DECLARE v_aporteIess DECIMAL(10,2);
    DECLARE v_totalEgresos DECIMAL(10,2);
    DECLARE v_totalIngresos DECIMAL(10,2);
    DECLARE v_netoPagar DECIMAL(10,2);

    -- Obtener el sueldo base del empleado
    SELECT salario INTO v_sueldo FROM cargo WHERE idCargo = (SELECT idCargo FROM empleado WHERE idEmpleado = p_idEmpleado);

    -- Obtener horas trabajadas del mes
    SET v_horasTrabajadas = (SELECT obtenerHorasTrabajadas(p_idEmpleado, p_mes, p_anio));

    -- Calcular horas extras y suplementarias
    SET v_horasExtras = (SELECT obtenerHorasExtras(p_idEmpleado, p_mes, p_anio));  
    SET v_horasSuplementarias = (SELECT obtenerHorasSuplementarias(p_idEmpleado, p_mes, p_anio));

    -- Calcular beneficios laborales
    SET v_decimotercerSueldo = (v_sueldo / 12);
    SET v_decimocuartoSueldo = (425 / 12);  -- Valor referencial en Ecuador, cámbialo si es diferente
    SET v_fondoReserva = (v_sueldo * 0.0833);

    -- Calcular deducciones
    SET v_aporteIess = (v_sueldo + v_horasExtras + v_horasSuplementarias) * 0.0945;

    -- Total de ingresos y egresos
    SET v_totalIngresos = v_sueldo + v_horasExtras + v_horasSuplementarias + v_decimotercerSueldo + v_decimocuartoSueldo + v_fondoReserva;
    SET v_totalEgresos = v_aporteIess;
    
    -- Neto a pagar
    SET v_netoPagar = v_totalIngresos - v_totalEgresos;

    -- Insertar el rol de pago
    INSERT INTO rolPago (
        numRol, mes, anio, fechaEmision, idEmpleado, sueldo, horasTrabajadas, horasExtras, horasSuplementarias, 
        decimotercerSueldo, decimocuartoSueldo, fondoReserva, aporteIess, totalIngresos, totalEgresos, netoPagar
    ) VALUES (
        p_numRol, p_mes, p_anio, CURDATE(), p_idEmpleado, v_sueldo, v_horasTrabajadas, v_horasExtras, v_horasSuplementarias,
        v_decimotercerSueldo, v_decimocuartoSueldo, v_fondoReserva, v_aporteIess, v_totalIngresos, v_totalEgresos, v_netoPagar
    );
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `generar_rol_pago_completo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `generar_rol_pago_completo`(
    IN p_numRol INT,
    IN p_idEmpleado INT,
    IN p_mes CHAR(2),
    IN p_anio YEAR
)
BEGIN
    DECLARE v_sueldo_mensual DECIMAL(10,2);
    DECLARE v_horas_suplementarias DECIMAL(10,2);
    DECLARE v_horas_extras DECIMAL(10,2);
    DECLARE v_total_horas_suplementarias DECIMAL(10,2);
    DECLARE v_total_horas_extras DECIMAL(10,2);
    DECLARE v_decimotercero DECIMAL(10,2);
    DECLARE v_decimocuarto DECIMAL(10,2);
    DECLARE v_fondo_reserva DECIMAL(10,2);
    DECLARE v_aporte_iess DECIMAL(10,2);
    DECLARE v_total_anticipos DECIMAL(10,2) DEFAULT 0;
    DECLARE v_descuento_faltas DECIMAL(10,2) DEFAULT 0;  -- otros descuentos
    DECLARE v_descuento_horas DECIMAL(10,2) DEFAULT 0;
    DECLARE v_descuentoTardanzas DECIMAL(10,2) DEFAULT 0; -- Variable añadida
    DECLARE v_total_ingresos DECIMAL(10,2);
    DECLARE v_total_egresos DECIMAL(10,2);
    DECLARE v_neto_pagar DECIMAL(10,2);
    
    -- 1. Obtener sueldo mensual
    SELECT c.salario INTO v_sueldo_mensual
    FROM empleado e
    JOIN cargo c ON e.idCargo = c.idCargo
    WHERE e.idEmpleado = p_idEmpleado;
    
    -- 2. Calcular horas suplementarias y extras del mes
    SELECT 
        COALESCE(SUM(horasSuplementarias), 0),
        COALESCE(SUM(horasExtras), 0)
    INTO 
        v_horas_suplementarias,
        v_horas_extras
    FROM asistencia
    WHERE idEmpleado = p_idEmpleado
    AND MONTH(fecha) = p_mes
    AND YEAR(fecha) = p_anio;
    
    -- 3. Calcular valores monetarios de horas
    SET v_total_horas_suplementarias = calcular_pago_horas_suplementarias(v_sueldo_mensual, v_horas_suplementarias);
    SET v_total_horas_extras = calcular_pago_horas_extras(v_sueldo_mensual, v_horas_extras);
    
    -- 4. Beneficios laborales
    SET v_decimotercero = calcular_decimo_tercero(v_sueldo_mensual, v_total_horas_suplementarias, v_total_horas_extras);
    SET v_decimocuarto = calcular_decimo_cuarto();
    SET v_fondo_reserva = calcular_fondo_reserva(v_sueldo_mensual, v_total_horas_suplementarias, v_total_horas_extras);
    
    -- 5. Aporte IESS
    SET v_aporte_iess = calcular_aporte_iess(v_sueldo_mensual, v_total_horas_suplementarias, v_total_horas_extras);
    
    -- 6. Obtener anticipos
    SELECT COALESCE(SUM(monto), 0) INTO v_total_anticipos
    FROM anticipo
    WHERE idEmpleado = p_idEmpleado
    AND MONTH(fecha) = p_mes
    AND YEAR(fecha) = p_anio
    AND isDeleted = FALSE;
    
    -- 7. Calcular descuentos por faltas completas
    SET v_descuento_faltas = calcular_sueldo_diario(v_sueldo_mensual) * obtener_dias_faltados(p_idEmpleado, p_mes, p_anio);
    
    -- 8. Calcular descuentos por tardanzas (horas no trabajadas)
    SELECT COALESCE(SUM(
        CASE 
            WHEN justificado = FALSE THEN 
                horasNOTrabajadas * calcular_sueldo_hora(v_sueldo_mensual)
            ELSE 0 
        END
    ), 0) INTO v_descuentoTardanzas
    FROM asistencia
	WHERE idEmpleado = p_idEmpleado
	AND MONTH(fecha) = p_mes  -- ¡Falta este filtro!
	AND YEAR(fecha) = p_anio;  -- ¡Falta este filtro!
    
    -- 9. Totales
    SET v_total_ingresos = v_sueldo_mensual + v_total_horas_suplementarias + v_total_horas_extras+ v_decimotercero + v_decimocuarto + v_fondo_reserva;
    SET v_total_egresos = v_aporte_iess + v_total_anticipos + v_descuento_faltas + v_descuentoTardanzas;
    SET v_neto_pagar = v_total_ingresos - v_total_egresos;
    
    -- 10. Insertar en rolPago
    INSERT INTO rolPago (
        numRol,
        mes,
        anio,
        fechaEmision,
        idEmpleado,
        sueldo,
        horasSuplementarias,
        horasExtras,
        decimotercerSueldo,
        decimocuartoSueldo,
        fondoReserva,
        aporteIess,
        anticipos,
        otrosDescuentos,
        descuentoTardanzas,
        totalEgresos,
        totalIngresos,
        netoPagar
    ) VALUES (
        p_numRol,
        p_mes,
        p_anio,
        CURDATE(),
        p_idEmpleado,
        v_sueldo_mensual,
        v_total_horas_suplementarias,
        v_total_horas_extras,
        v_decimotercero,
        v_decimocuarto,
        v_fondo_reserva,
        v_aporte_iess,
        v_total_anticipos,
        v_descuento_faltas,
        v_descuentoTardanzas,
        v_total_egresos,
        v_total_ingresos,
        v_neto_pagar
    );
    
    SELECT CONCAT('Rol de pago generado correctamente para el empleado ID: ', p_idEmpleado) AS mensaje;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getActiveDpt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getActiveDpt`()
BEGIN
    SELECT * FROM departamento WHERE isDeleted = FALSE;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertarAsistenciasPrueba` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insertarAsistenciasPrueba`(
    IN p_idEmpleado INT, 
    IN p_mes CHAR(2), 
    IN p_anio YEAR
)
BEGIN
    DECLARE v_dia INT DEFAULT 1;
    DECLARE v_fecha DATE;
    
    -- Recorre los días del mes
    WHILE v_dia <= 31 DO
        -- Construye la fecha
        SET v_fecha = STR_TO_DATE(CONCAT(p_anio, '-', p_mes, '-', LPAD(v_dia, 2, '0')), '%Y-%m-%d');
        
        -- Verifica si es lunes a viernes
        IF WEEKDAY(v_fecha) < 5 THEN
            -- Inserta la asistencia con entrada a las 08:00 y salida a las 17:00
            INSERT INTO asistencia (idEmpleado, fecha, horaEntrada, horaSalida) 
            VALUES (p_idEmpleado, v_fecha, '08:00:00', '17:00:00');
        END IF;
        
        -- Avanza al siguiente día
        SET v_dia = v_dia + 1;
    END WHILE;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `JustificarAsistencia` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `JustificarAsistencia`(
    IN p_idEmpleado INT,
    IN p_fechaInicio DATE,
    IN p_fechaFin DATE,
    IN p_motivo ENUM('Vacaciones', 'Salud', 'Otro'),
    IN p_detalle TEXT
)
BEGIN
    DECLARE v_fechaActual DATE;
    DECLARE v_diaSemana INT;
    DECLARE v_horaEntrada TIME;
    DECLARE v_horaSalida TIME;
    DECLARE v_idJustificacion INT DEFAULT NULL;
    DECLARE v_dias_laborables INT DEFAULT 0;
    DECLARE v_justificacion_existente INT;
    
    -- Verificar días laborables en el rango
    SET v_fechaActual = p_fechaInicio;
    WHILE v_fechaActual <= p_fechaFin DO
        IF WEEKDAY(v_fechaActual) < 5 THEN -- 0-4 = Lunes a Viernes
            SET v_dias_laborables = v_dias_laborables + 1;
        END IF;
        SET v_fechaActual = DATE_ADD(v_fechaActual, INTERVAL 1 DAY);
    END WHILE;
    
    -- Crear justificación solo si hay días laborables
    IF v_dias_laborables > 0 THEN
        INSERT INTO justificacion (motivo, detalle)
        VALUES (p_motivo, p_detalle);
        SET v_idJustificacion = LAST_INSERT_ID();
    END IF;
    
    -- Procesar cada día del rango
    SET v_fechaActual = p_fechaInicio;
    
    WHILE v_fechaActual <= p_fechaFin DO
        SET v_diaSemana = WEEKDAY(v_fechaActual);
        
        -- Solo procesar días laborables (L-V)
        IF v_diaSemana < 5 THEN
            -- Verificar si ya existe justificación para este día
            SELECT COUNT(*) INTO v_justificacion_existente
            FROM asistencia
            WHERE idEmpleado = p_idEmpleado
            AND fecha = v_fechaActual
            AND justificado = TRUE;
            
            -- Solo proceder si no existe justificación previa
            IF v_justificacion_existente = 0 THEN
                -- Verificar si existe registro de asistencia
                SELECT horaEntrada, horaSalida INTO v_horaEntrada, v_horaSalida
                FROM asistencia
                WHERE idEmpleado = p_idEmpleado
                AND fecha = v_fechaActual
                LIMIT 1;
                
                -- Si no existe registro, crear uno nuevo con hora de entrada 08:00 y hora de salida 17:00
                IF v_horaEntrada IS NULL THEN
                    INSERT INTO asistencia (
                        idEmpleado, 
                        fecha, 
                        horaEntrada, 
                        horaSalida, 
                        justificado, 
                        idJustificacion
                    )
                    VALUES (
                        p_idEmpleado, 
                        v_fechaActual, 
                        '08:00:00', 
                        '17:00:00',  -- Hora de salida inicial a las 5 PM
                        TRUE, 
                        v_idJustificacion
                    );

                    -- Ahora actualizamos el registro recién creado para asegurarnos de que la hora de salida es 17:00
                    UPDATE asistencia
                    SET horaSalida = '17:00:00'
                    WHERE idEmpleado = p_idEmpleado
                    AND fecha = v_fechaActual
                    AND justificado = TRUE
                    AND idJustificacion = v_idJustificacion;
                ELSE
                    -- Si existe registro, actualizar con hora de salida a las 17:00 si es menor
                    UPDATE asistencia
                    SET 
                        horaEntrada = IF(v_horaEntrada > '08:00:00', '08:00:00', v_horaEntrada),
                        horaSalida = IF(v_horaSalida < '17:00:00', '17:00:00', v_horaSalida),
                        justificado = TRUE,
                        idJustificacion = v_idJustificacion
                    WHERE 
                        idEmpleado = p_idEmpleado
                        AND fecha = v_fechaActual;
                END IF;
            END IF;
        END IF;
        
        SET v_fechaActual = DATE_ADD(v_fechaActual, INTERVAL 1 DAY);
    END WHILE;
    
    -- Mensaje informativo
    SELECT CONCAT('Proceso completado. ', 
                  IF(v_dias_laborables > 0, 
                     CONCAT(v_dias_laborables, ' días laborables procesados.'), 
                     'No se procesaron días laborables en el rango.')) AS resultado;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `RegistrarAsistenciaPorHuella` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `RegistrarAsistenciaPorHuella`(IN huella_id INT)
BEGIN
    DECLARE empleado_id INT;
    DECLARE fecha_actual DATE;
    DECLARE existe_asistencia INT;
    DECLARE hora_entrada TIME;
    
    START TRANSACTION;
    
    -- Obtener ID del empleado y fecha actual
    SELECT idEmpleado INTO empleado_id 
    FROM empleado 
    WHERE huella = huella_id 
    AND isDeleted = FALSE;
    
    SET fecha_actual = CURDATE();
    
    -- Verificar si existe registro de asistencia
    SELECT COUNT(*) INTO existe_asistencia 
    FROM asistencia 
    WHERE idEmpleado = empleado_id 
    AND fecha = fecha_actual;
    
    IF empleado_id IS NULL THEN
        SELECT 'Error: No existe empleado con esta huella' AS Resultado;
        ROLLBACK;
    ELSE
        IF existe_asistencia = 0 THEN
            -- Registrar entrada
            INSERT INTO asistencia (idEmpleado, fecha, horaEntrada)
            VALUES (empleado_id, fecha_actual, CURTIME());
            
            SELECT 'Entrada registrada correctamente' AS Resultado;
        ELSE
            -- Registrar salida
            UPDATE asistencia 
            SET 
                horaSalida = CURTIME(),
                horasTrabajadas = TIMESTAMPDIFF(HOUR, horaEntrada, CURTIME())
            WHERE idEmpleado = empleado_id 
            AND fecha = fecha_actual;
            
            SELECT 'Salida registrada correctamente' AS Resultado;
        END IF;
    END IF;
    
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_obtenerRolPagoCompletoPorId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_obtenerRolPagoCompletoPorId`(IN p_idRol INT)
BEGIN
    SELECT 
        rp.idRol,
        rp.numRol,
        rp.mes,
        rp.anio,
        rp.fechaEmision,

        -- EMPLEADO
        e.idEmpleado,
        e.cedula,
        e.nombreEmpleado,
        e.fechaContratacion,
        e.telefono,
        e.direccion,
        e.fechaNacimiento,

        -- CARGO Y DEPARTAMENTO
        c.nombreCargo,
        d.nombreDepartamento,
        c.salario AS sueldoBase,

        -- INGRESOS
        rp.sueldo,
        rp.horasSuplementarias,
        rp.horasExtras,
        rp.decimotercerSueldo,
        rp.decimocuartoSueldo,
        rp.fondoReserva,
        rp.totalIngresos,

        -- EGRESOS
        rp.aporteIess,
        rp.anticipos,
        rp.otrosDescuentos,
        rp.descuentoTardanzas,
        rp.totalEgresos,

        -- TOTAL NETO
        rp.netoPagar,

        -- HORAS DEL MES
        (
            SELECT SEC_TO_TIME(SUM(TIME_TO_SEC(IFNULL(a.horasTrabajadasTiempo, '00:00:00'))))
            FROM asistencia a
            WHERE a.idEmpleado = rp.idEmpleado
              AND MONTH(a.fecha) = CAST(rp.mes AS UNSIGNED)
              AND YEAR(a.fecha) = rp.anio
              AND a.isDeleted = FALSE
        ) AS totalHorasTrabajadas,

        (
            SELECT SEC_TO_TIME(SUM(TIME_TO_SEC(IFNULL(a.horasExtrasTiempo, '00:00:00'))))
            FROM asistencia a
            WHERE a.idEmpleado = rp.idEmpleado
              AND MONTH(a.fecha) = CAST(rp.mes AS UNSIGNED)
              AND YEAR(a.fecha) = rp.anio
              AND a.isDeleted = FALSE
        ) AS totalHorasExtras,

        (
            SELECT SEC_TO_TIME(SUM(TIME_TO_SEC(IFNULL(a.horasSuplementariasTiempo, '00:00:00'))))
            FROM asistencia a
            WHERE a.idEmpleado = rp.idEmpleado
              AND MONTH(a.fecha) = CAST(rp.mes AS UNSIGNED)
              AND YEAR(a.fecha) = rp.anio
              AND a.isDeleted = FALSE
        ) AS totalHorasSuplementarias,

        (
            SELECT SEC_TO_TIME(SUM(TIME_TO_SEC(IFNULL(a.horasNOTrabajadasTiempo, '00:00:00'))))
            FROM asistencia a
            WHERE a.idEmpleado = rp.idEmpleado
              AND MONTH(a.fecha) = CAST(rp.mes AS UNSIGNED)
              AND YEAR(a.fecha) = rp.anio
              AND a.isDeleted = FALSE
        ) AS totalHorasNoTrabajadas

    FROM rolPago rp
    JOIN empleado e ON rp.idEmpleado = e.idEmpleado
    JOIN cargo c ON e.idCargo = c.idCargo
    JOIN departamento d ON e.idDepartamento = d.idDepartamento
    WHERE rp.idRol = p_idRol AND rp.isDeleted = FALSE;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateDpt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `updateDpt`(IN id INT, IN nuevoNombre VARCHAR(50))
BEGIN
    UPDATE departamento SET nombreDepartamento = nuevoNombre WHERE idDepartamento = id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-03 22:11:03
