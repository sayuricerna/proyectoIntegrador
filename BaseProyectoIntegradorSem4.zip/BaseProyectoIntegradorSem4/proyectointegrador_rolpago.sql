CREATE DATABASE  IF NOT EXISTS `proyectointegrador` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `proyectointegrador`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: proyectointegrador
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rolpago`
--

DROP TABLE IF EXISTS `rolpago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rolpago` (
  `idRol` int NOT NULL AUTO_INCREMENT,
  `numRol` int NOT NULL,
  `isDeleted` tinyint(1) DEFAULT '0',
  `mes` char(2) NOT NULL,
  `anio` year NOT NULL,
  `fechaEmision` date NOT NULL,
  `idEmpleado` int NOT NULL,
  `sueldo` decimal(10,2) NOT NULL,
  `horasSuplementarias` decimal(10,2) DEFAULT '0.00',
  `horasExtras` decimal(10,2) DEFAULT '0.00',
  `decimotercerSueldo` decimal(10,2) DEFAULT '0.00',
  `decimocuartoSueldo` decimal(10,2) DEFAULT '0.00',
  `fondoReserva` decimal(10,2) DEFAULT '0.00',
  `aporteIess` decimal(10,2) DEFAULT '0.00',
  `anticipos` decimal(10,2) DEFAULT '0.00',
  `otrosDescuentos` decimal(10,2) DEFAULT '0.00',
  `descuentoTardanzas` decimal(10,2) DEFAULT '0.00',
  `totalEgresos` decimal(10,2) DEFAULT '0.00',
  `totalIngresos` decimal(10,2) DEFAULT '0.00',
  `netoPagar` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`idRol`),
  UNIQUE KEY `numRol` (`numRol`),
  KEY `idEmpleado` (`idEmpleado`),
  CONSTRAINT `rolpago_ibfk_1` FOREIGN KEY (`idEmpleado`) REFERENCES `empleado` (`idEmpleado`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rolpago`
--

LOCK TABLES `rolpago` WRITE;
/*!40000 ALTER TABLE `rolpago` DISABLE KEYS */;
INSERT INTO `rolpago` VALUES (1,1,1,'04',2025,'2025-04-14',56,1800.00,0.00,0.00,150.00,39.17,149.94,170.10,0.00,60.00,0.00,230.10,2139.11,1909.01),(2,2,1,'04',2025,'2025-04-14',35,500.00,0.00,0.00,41.67,39.17,41.65,47.25,124.24,333.40,0.00,504.89,622.49,117.60),(10,3,0,'03',2025,'2025-04-15',61,800.00,0.00,0.00,66.67,39.17,66.64,75.60,0.00,0.00,0.00,75.60,972.48,896.88),(12,4,1,'03',2025,'2025-04-15',60,800.00,0.00,0.00,66.67,39.17,66.64,75.60,0.00,0.00,0.00,75.60,972.48,896.88),(13,5,1,'03',2025,'2025-04-15',67,800.00,5.00,0.00,67.08,39.17,67.06,76.07,0.00,26.67,9.99,112.73,978.31,865.58),(14,6,1,'03',2025,'2025-04-15',67,800.00,5.00,0.00,67.08,39.17,67.06,76.07,0.00,26.67,9.99,112.73,978.31,865.58),(15,7,1,'03',2025,'2025-04-15',67,800.00,5.00,0.00,67.08,39.17,67.06,76.07,0.00,26.67,9.99,112.73,978.31,865.58),(16,8,0,'03',2025,'2025-04-15',67,800.00,5.00,0.00,67.08,39.17,67.06,76.07,0.00,26.67,9.99,112.73,978.31,865.58);
/*!40000 ALTER TABLE `rolpago` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `PreventDuplicateRolPago` BEFORE INSERT ON `rolpago` FOR EACH ROW BEGIN
    -- Verifica si ya existe un rol de pago activo para este empleado, mes y año
    IF EXISTS (SELECT 1 FROM rolPago 
               WHERE idEmpleado = NEW.idEmpleado 
                 AND mes = NEW.mes 
                 AND anio = NEW.anio 
                 AND isDeleted = false) THEN
        -- Si existe, lanza un error
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No se puede insertar un rol de pago duplicado para este empleado en el mismo mes y año';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `after_insert_rolPago` AFTER INSERT ON `rolpago` FOR EACH ROW BEGIN
    DECLARE diasTrabajados INT;

    -- Contar los días distintos en los que tuvo asistencia
    SELECT COUNT(DISTINCT DATE(fecha))
    INTO diasTrabajados
    FROM asistencia
    WHERE idEmpleado = NEW.idEmpleado
      AND MONTH(fecha) = CAST(NEW.mes AS UNSIGNED)
      AND YEAR(fecha) = NEW.anio
      AND isDeleted = FALSE;

    -- Si trabajó menos de 15 días, lanzar señal
    IF diasTrabajados < 15 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Este empleado trabajó menos de 15 días. Se requiere revisión manual.';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-03 22:11:01
